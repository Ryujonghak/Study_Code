// 1251 : 1 부터 100까지 출력하기
// 입력 : 입력없음
// 출력 : 1부터 100까지 공백으로 띄워 하나씩 출력한다.

// let result9 = "";
// for(let i = 1;i<=100;i++){
//     result9 += i+" ";
// }
// alert(result9);

// 1252 : 1 부터 n 까지 출력하기
// 입력 : 5
// 출력 : 1부터 n까지 공백으로 띄워 출력한다.

// let inp = prompt();
// let result = "";
// for(let i = 1;i<=inp;i++){
//     result += i+" ";
// }
// alert(result);

// 1253 : a 부터 b까지 출력하기
// 입력 : 두 수 a, b가 입력으로 들어온다. ( a, b는 정수, a, b 중 어떤 수가 큰지 모름)
// 출력 : a와 b 사이의 정수들을 오름차순으로 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = "";
// if(inp[0] > inp[1]){
//     for(let i = inp[1];i<=inp[0];i++){
//         result += i+" ";
//     }
// }else{
//     for(let i = inp[0];i<=inp[1];i++){
//         result += i+" ";
//     }
// }
// alert(result);


// 1254 : 알파벳 출력하기
// 입력 : d g
// 출력 : d e f g 

// let inp = prompt().split(" ");
// let inp2 = inp[0].charCodeAt(0)
// let inp3 = inp[1].charCodeAt(0)
// let result = "";
// for(let i =inp2; i<=inp3;i++){
//     result = result + " " + String.fromCharCode(i);
// }alert(result);


// 1255 : 두 실수 사이 출력하기
// 입력 : 2.00 2.03
// 출력 : 2.00 2.01 2.02 2.03 
 
// let inp = prompt().split(" ");
// let inp2 = Number((inp[0]*100).toFixed(0));
// let inp3 =  Number((inp[1]*100).toFixed(0));
// let inp4 = inp3-inp2;
// let result = "";
// for(let i=0;i<=inp4;i++){
//     result += " "+((inp2+i)/100).toFixed(2);
// }alert(result);


// 1256 : 별 출력하기
// 입력 : 5
// 출력 : *****

// let inp = prompt();
// let result = "";
// for(let i = 0; i<inp;i++){
//     result += "*"
// }alert(result)

// 1257 : 두 수 사이의 홀수 출력하기
// 입력 : 2 7
// 출력 : a~b의 홀수를 모두 출력한다.

// let inp = prompt().split(" ");
// let result = "";
// for(let i = inp[0]; i<=inp[1];i++){
//     if(i%2 !=0){
//         result += i+" ";
//     }
// }alert(result);

// 1258 : 1부터 n까지 합 구하기
// 입력 : 100
// 출력 : 1부터 n까지의 합을 출력한다.

// let inp = prompt();
// let result = 0;
// for(let i=0;i<=inp;i++){
//     result += i;
// }alert(result);

// 1259 : 1부터 n까지 중 짝수의 합 구하기
// 입력 : 5
// 출력 : 1부터 n까지의 짝수의 합을 출력하시오.

// let inp = prompt();
// let result = 0;
// for(let i = 0; i<=inp;i++){
//     if(i%2==0){
//         result += i;
//     }
// }alert(result);

// 1260 : 3의 배수의 합
// 입력 : 3 7
// 출력 : a~b까지의 수 중 3의 배수의 합을 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = 0;
// for(let i = inp[0];i<=inp[1];i++){
//     if(i%3==0){
//         result += i;
//     }
// }alert(result);

// 1261 : First Special Judge (Test)
// 입력 : 1 2 3 4 5 6 7 8 9 10
// 출력 : 10개의 수 중 5의 배수가 있으면 그 중 하나만 출력하고, 없다면 0을 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = 0;
// for(let i =1; i<=inp.length;i++){
//     if(i%5==0){
//         result += i;
//         break;
//     }
// }alert(result);

// 1265 : 구구단 출력하기 1
// 입력 : 3
// 출력 : 3*1=3
//        3*2=6
//        3*3=9
//        3*4=12
//        3*5=15
//        3*6=18
//        3*7=21
//        3*8=24
//        3*9=27

// let inp = Number(prompt());
// let result = "";
// for(let i =1;i<=9;i++){
//     result += inp + "*" + i + "=" + (inp*i) + "\n";
// }alert(result);


// 1266 : n개의 수의 합
// 입력 : 3 5 7 7 2
// 출력 : 24

// let inp1 = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = 0;
// for(let i =0; i<inp1;i++){
//     result += inp2[i];
// }alert(result);

// 1267 : n개의 수 중 5의 배수의 합
// 입력 : 3 5 7 15 2
// 출력 : n개의 자연수들 중 5의 배수의 합을 출력한다.

// let inp1 = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = 0;
// for(let i=0;i<inp2.length;i++){
//     if(inp2[i]%inp1==0){
//         result += inp2[i];
//     }
// }alert(result);

// 1268 : n개의 수 중 짝수의 개수
// 입력 : 3 5 7 15 2
// 출력 : n개의 자연수들 중 짝수의 개수를 출력한다.

// let inp1 = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = 0;
// for(let i=0;i<inp2.length;i++){
//     if(inp2[i] % 2==0){
//         result += 1;
//     }
// }alert(result);

// 1269 : 수열의 값 구하기
// 입력 : 2 -1 3 5
// 출력 : n번째 수열의 값을 출력한다.

// let inp2 = prompt().split(" ").map(Number);
// let result = 2;
// for(let i=1;i<inp2[3];i++){
//     result = result*inp2[1]+inp2[2];
// }alert(result);

// 1270 : 1의 개수는? 1
// 입력 : 35
// 출력 : 맨 마지막 자리에 1이 몇 번 들어 있는지 출력한다.

// let inp = prompt();
// let result = 1;
// for(let i =2;i<inp;i++){
//     if((i%10)==1){   
//         result += 1
//     }
// }alert(result);


// 1271 : 최댓값 구하기
// 입력 : 3 1 29 31 21 
// 출력 :  N개의 정수 중 최댓값을 찾아 출력한다.

// let inp1 = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = inp2[0];
// for(let i=0;i<inp1;i++){
//     if(result>inp2[i]){
//         result = result;
//     }else{
//         result = inp2[i];
//     }
// }alert(result);

// 1272 : 기부
// 입력 : 1 2 7 6
// 출력 : 존과 밥이 받는 금액의 합을 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = 0;
// for(let i=0;i<inp.length;i++){
//     if(inp[i]%2==0){
//         result += inp[i]*5;
//     }else{
//         for(let k=1;k<=inp[i];k++){
//             if(k%2!=0){
//                 result += 1;  
//             }
//         }
//     }
// }alert(result);

// 1273 : 약수 구하기
// 입력 : 
// 출력 : 
// let inp = prompt()
// let result = "";
// for(let i=0;i<=inp;i++){
// 	if(inp%i == 0){
// 	    result += " "+i;
// 	}
// }alert(result);

// 1274 : 소수 판별
// 입력 : 7
// 출력 : 입력으로 주어진 수가 소수이면 "prime"을 출력, 소수가 아니면 "not prime"을 출력한다.

// let inp = prompt();
// let result = "";
// for(let i=2; i<=inp;i++){
// 	if(inp%i==0){
// 		result = i;
// 		break;
// 	}
// }
// if(inp==result){
// 	alert("prime")
// }else{
// 	alert("not prime")
// }

// 1275 : k 제곱 구하기
// 입력 : 3 3
// 출력 : 27

// let inp = prompt().split(" ").map(Number);
// let result = inp[0]
// for(let i=0;i<inp[1];i++){
// 	result = result*inp[1];
// }alert(result);

// 1276 : 팩토리얼 계산
// 입력 : 5
// 출력 : 120

// let inp = prompt();
// let result = inp;
// for(let i=1;i<inp;i++){
// 	result = result*(inp-i);
// }alert(result);

// 1277 : 몇 번째 데이터 출력하기
// 입력 : N(N은 홀수)이 입력되고 
//               7
//          2 4 7 3 1 2 5
// 출력 : 첫번째, 중간, 마지막 데이터 값을 출력한다.

// let inp = prompt();
// let inp2 =  prompt().split(" ").map(Number);
// let inp3 = Math.floor(inp/2);
// let inp4 = (inp-1);
// let result = inp2[0];
// for(let i=0; i<inp;i++){
//     if(inp2[inp3]==inp2[i]){
//         result += " "+inp2[inp3];
//     }
//     if(inp2[inp4]==inp2[i]){
//         result += " "+inp2[inp4];
//     }
// }alert(result);

// 1278 : 자릿수 계산
// 입력 : 932
// 출력 : 그 숫자가 몇 자릿수 인지 출력하시오.

// let inp = prompt();
// let result = 0;
// for(let i=0;true;i++){
//     result += 1 
//     inp = (inp/10)
//     if(inp<1){
//         break;
//     }
// }alert(result);

// 1279 : 홀수는 더하고 짝수는 빼고 1
// 입력 : 5 10
// 출력 : a, b 사이의 수 중 홀수는 더하고 짝수는 뺀 결과를 출력하시오.

// let inp = prompt().split(" ").map(Number);
// let result = 0;
// for(let i=inp[0];i<=inp[1];i++){
//     if(i%2 == 0){
//         result += -i;
//     }
//     else{
//         result += i;
//     }
// }alert(result);


// 1280 : 홀수는 더하고 짝수는 빼고 2
// 입력 : 5 7
// 출력 : +5-6+7=6

// let inp = prompt().split(" ").map(Number);
// let result1 = "";
// let result2 = 0;
// for(let i =inp[0];i<=inp[1];i++){
//     if(i%2==0){
//         result2 += -i;
//         result1 += "-"i;
//     }else{
//         result2 += +i;
//         result1 += "+"+i;
//     }
// }alert(result1+"="+result2)


// 1281 : 홀수는 더하고 짝수는 빼고 3
// 입력 : 5 7
// 출력 : 5-6+7=6


// let inp = prompt().split(" ").map(Number);
// let result1 = ""; // 1번째문자
// let result2 = ""; // 2번째 문자
// let result3 = 0; //토탈 값

// if(inp[0]%2==0){
//     result1 = "-"+inp[0];
// }else{
//     result1 = inp[0];
// }
// // 첫번째 값

// for(let i =inp[0];i<inp[1];i++){
//     if((i+1)%2==0){
//         result2 += "-"+(i+1);
//     }else{
//         result2 += "+"+(i+1);
//     }    
// }
// // 두번째 값

// for(let j =inp[0];j<=inp[1];j++){
//     if(j%2==0){
//         result3 += -j;
//     }else{
//         result3 += +j;
//     }
// }
// // 결과값

// alert(result1+result2+"="+result3);

