// 1110 : 정수 그대로 출력하기
// 입력 : 5
// 출력 : 5

// let inp = prompt("정수");
// alert(inp);

// 1111 : %출력
// 입력 : 35
// 출력 : 35%

// let inp = prompt("정수");
// alert(inp+"%");

// 1112 : 두 정수 출력
// 입력 : 5 7
// 출력 : 5 7

// let inp = prompt("정수").split(" ").map(Number);
// alert(inp[0]+ " " +inp[1]);

// 1113 : 바꿔서 출력하기
// 입력 :  1 2
// 출력 :  2 1

// let inp = prompt("정수").split(" ").map(Number);
// alert(inp[1]+ " " +inp[0]);

// 1114 : 두 정수의 덧셈
// 입력 :  5 7
// 출력 :  12

// let inp = prompt("정수").split(" ").map(Number);
// alert(inp[0]+inp[1]);

// 1115 : 두 정수의 덧셈 (64비트)
// 입력 :  11111111111 22222222222
// 출력 :  33333333333

// let inp = prompt("정수").split(" ").map(Number);
// alert(inp[0]+inp[1]);

// 1116 : 사칙연산 계산기
// 입력 :  3 2
// 출력 :  3+2=5
//         3-2=1
//         3*2=6
//         3/2=1

// let inp = prompt("정수").split(" ").map(Number);
// let inp2 = inp[0]+inp[1]+"\n";
// let inp3 = inp[0]-inp[1]+"\n";
// let inp4 = inp[0]*inp[1]+"\n";
// let inp5 = Math.floor(inp[0]/inp[1]);
// alert(inp2+inp3+inp4+inp5); 

// 1117 : 두 실수의 곱
// 입력 :  1.23 4.56
// 출력 :  5.61

// let inp = prompt("실수").split(" ").map(Number);
// let inp1 = (inp[0]*inp[1]).toFixed(2) ;
// alert(inp1);


// 1118 : 삼각형의 넓이 구하기// 입력 : 
// 입력 : 5 2
// 출력 : 5.0

// let inp = prompt("").split(" ").map(Number);
// let inp2 = (inp[0]*inp[1])/2;
// alert(inp2.toFixed(1));

// 1119 : 일을 시간으로 변환
// 입력 : 2
// 출력 : 48

// let inp = prompt("");
// alert(inp*24);

// 1120 : 세 수의 평균
// 입력 : 1 2 3
// 출력 : 2.00

// let inp = prompt("").split(" ").map(Number);
// let inp2 = (inp[0]+inp[1]+inp[2])/3;
// alert(inp2.toFixed(2));

// 1121 : 나머지 구하기
// 입력 : 7 5
// 출력 : 2

// let inp = prompt("").split(" ").map(Number);
// alert(inp[0]%inp[1]);

// 1122 : 초를 분/초로 변환
// 입력 : 70
// 출력 : 1 10

// let inp = prompt("");
// let inp2 = Math.floor(inp/60);
// let inp3 = inp2*60;
// if(inp>=60){
//     if(inp>=120){
//         alert(inp2 + " " +(inp3-inp));
//     }else{
//         alert(inp2 + " " +(inp-60));
//     }
// }else{
//     alert(inp);
// }

// 1123 : 섭씨 온도를 화씨 온도로 변환
// 입력 : 30
// 출력 : 86.000
// 화씨 온도 = 9 / 5 * 섭씨온도 + 32

// let inp = prompt("");
// let inp2 = 9/5*inp+32;
// alert(inp2);


// 1125 : 8진수 16진수 변환
// 입력 : 10
// 출력 : 12 A

// let inp =Number(prompt(""));
// let inp2 = inp.toString(16).toUpperCase();
// let inp3 = (inp).toString(8);
// alert(inp3 + " " +inp2);

// 1131 : 문자 출력하기
// 입력 : a
// 출력 : a

// let inp =prompt(" ");
// alert(inp);

// 1132 : 문자열 출력하기
// 입력 : cat
// 출력 : cat

// let inp =prompt(" ");
// alert(inp);

// 1133 : 공백이 있는 문자열 입출력
// 입력 : black sheep wall
// 출력 : black sheep wall

// let inp =prompt(" ");
// alert(inp);

// 1135 : 관계연산자 1
// 입력 : 2 3
// 출력 : 0

// let inp =prompt(" ").split(" ");
// if(inp[0]>=inp[1]){
//     alert(1);
// }else{
//     alert(0);
// }

// 1136 : 관계연산자 2
// 입력 : 2 3 
// 출력 : 0

// let inp =prompt(" ").split(" ");
// if(inp[0]==inp[1]){
//     alert(1);
// }else{
//     alert(0);
// }

// 1137 : 관계연산자 3
// 입력 : 2 3 
// 출력 : 0

// let inp =prompt(" ").split(" ");
// if(inp[0]!=inp[1]){
//     alert(1);
// }else{
//     alert(0);
// }

// 1138 : 논리 연산자(NOT)
// 입력 : 0 
// 출력 : 1

// let inp = prompt();
// if(inp == 0){
//     alert(1);
// }else{
//     alert(0);
// }


// 1139 : 논리 연산자(AND)
// 입력 : 1 0
// 출력 : 0

// let inp = prompt().split(" ");
// if(inp[0] == 0 && inp[1] == 0){
//     alert(1);
// }else{   
//     alert(0);
// }

// 1140 : 논리 연산자(OR)
// 입력 : 0 1
// 출력 : 1

// let inp = prompt().split(" ");
// if(inp[0] == 0 || inp[1] == 0){
//     alert(1);
// }else{
//     alert(0);
// }

// 1149 : 두 수 중 큰 수
// 입력 : 2 7
// 출력 : 7

// let inp = prompt().split(" ").map(Number);
// alert(Math.max(...inp));

// 1150 : 세 수 중 가장 작은 수
// 입력 : 3 5 2
// 출력 : 2

// let inp = prompt().split(" ").map(Number);
// alert(Math.min(...inp));
