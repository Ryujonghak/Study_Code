// 1602 : 절대값 함수
// 입력 : 정수 또는 실수 n이 입력된다. (n은 정수 또는 실수)
// 출력 : 입력된 n의 절대값을 출력한다. 실수값일 경우 불필요한 0을 출력하지 않는다.

// let inp = prompt()
// function inp2(){
//     if(inp>0){
//         return inp
//     }else{
//         return -inp
//     }
// }
// console.log(inp2())



// 1294 : 시저의 암호 2
// 입력 : never trust brutus
// 출력 : qhyhu wuxvw euxwxv


// 입력을 받은값을 아스키 코드로 변환을 한다.
// 아스키코드를 +3을 한다.
// 변환된 아스키 코드를 for문을 돌려서 다시 문자로 변환을 한다.

// let inp = prompt();
// let inp2 = "";
// let inp3 = "";
// let result = "";

// for(let i=0; i <inp.length;i++){
//     inp2 += " "+inp[i].charCodeAt(0) // 이렇게 하면 앞에 공백 하나 있고 공백으로 구분 되어 있음
// }

// let inp4 = inp2.split(" ").map(Number) 
// // 0 110 101 118 101 114 32 116 114 117 115 116 32 98 114 117 116 117 115 이 값의 공백을 지우고(배열로 만들어줌) 숫자로 변환

// for(let i=1; i<inp4.length;i++){
//     if(inp4[i] == 32){
//         inp3 += " "+inp4[i];                      
//         continue;                      
//     }else if(inp4[i] == 120){                      // x => a
//         inp3 += " "+97                      
//         continue;                      
//     }else if(inp4[i] == 121){                      // y => b 
//         inp3 += " "+98                      
//         continue;                      
//     }else if(inp4[i] == 122){                      // z => c
//         inp3 += " "+99                      
//         continue;
//     }
//     inp3 += " "+(inp4[i]+3);
// }

// let inp5 = inp3.split(" ").map(Number)
// // 0 113 104 121 104 117 32 119 117 120 118 119 32 101 117 120 119 120 118  //  

// for(let i=1;i<inp5.length;i++){
//     result += String.fromCharCode(inp5[i])
// }
// alert(result);  // 결과 값


// 1580 : (함수 작성) 원의 넓이
// 입력 : 이 프로그램은 int범위의 반지름 r을 입력으로 받습니다.
// 출력 : 입력된 반지름 r을 이용하여 원의 넓이를 구하는 circle 함수를 작성하시오. 함수 본체만 작성해서 제출한다.

// let inp = prompt();
// function circle (){
//     return (inp*inp*3.14).toFixed(2)
// }
// console.log(circle())