// 문자열 시작

// 1131 : 문자 출력하기
// 입력 : a
// 출력 : a

// let inp = prompt();
// alert(inp);

// 1132 : 문자열 출력하기
// 입력 : cat
// 출력 : cat

// let inp = prompt();
// alert(inp);

// 1133 : 공백이 있는 문자열 입출력
// 입력 : black sheep wall
// 출력 : black sheep wall

// let inp = prompt();
// alert(inp);

// 1295 : 알파벳 대소문자 변환
// 입력 : CodeChallenge2014withMSP
// 출력 : cODEcHALLENGE2014WITHmsp
// 65~90
// 97~122

// let inp = prompt();
// let result = "";

// for(let i = 0; i<inp.length;i++){
//     if(inp[i].charCodeAt() >= 65 && inp[i].charCodeAt() <=90){
//         result += inp[i].toLowerCase();
//     }
//     else if(inp[i].charCodeAt() >= 97 && inp[i].charCodeAt() <=122){
//         result += inp[i].toUpperCase();
//     }
//     else if(inp[i]>=0 && inp[i]<= 9){
//         result += inp[i];
//     }
// }
// alert(result);

// 1406 : love
// 입력 : love
// 출력 : I love you.

// let inp = prompt();
// if(inp == "love"){
//     alert("I love you.");
// }

// 1407 : 문자열 출력하기 1
// 입력 : abC Def gh
// 출력 : 공백을 제거한 후 출력한다.

// let inp = prompt().split(" ");
// alert(inp);

// 1408 : 암호 처리
// 입력 : TEST
// 출력 : VGUV
//        L3EL

// let inp = prompt().split("");
// let result = "";
// let result2 = "";

// for(let i= 0;i<inp.length;i++){
//     result += String.fromCharCode((inp[i]).charCodeAt(0)+2); //VGUV
// }

// for(let i = 0;i<inp.length;i++){
//     result2 += String.fromCharCode(((((inp[i]).charCodeAt(0))*7)%80)+48); //L3EL
// }alert(result+"\n"+result2);



// 1410 : 올바른 괄호 1 (괄호 개수 세기)
// 입력 : 괄호로 이루어진 문자열이 입력된다. (길이 100,000 이하)
// 출력 : 여는 괄호의 개수와 닫힌 괄호의 개수를 출력한다.

// let inp = prompt().split("");
// let result1 = 0;
// let result2 = 0;
// for(let i=0; i<inp.length;i++){
//     if(inp[i]== "(" ){
//         result1 += 1;
//     }
//     if(inp[i]== ")" ){
//         result2 += 1;
//     }
// }alert(result1 +" "+ result2);

// 1414 : C언어를 찾아라
// 입력 : cCCc
// 출력 : ① 첫 번째 줄에는 문자열에서 찾은 “C”의 개수를 출력한다.
//        ② 두 번째 줄에는 문자열에서 찾은 “CC”의 개수를 출력한다.

// let inp = prompt().split("");
// let result = 0;
// let result1 = 0;
// for(let i=0; i<inp.length;i++){
//     if(inp[i]== "c" || inp[i]== "C"){
//         result += 1;
//     }
// }
// for(let i=0; i<(inp.length)-1;i++){
//     if(inp[i]+inp[i+1] =="cc" ||inp[i]+inp[i+1] =="cC"||inp[i]+inp[i+1] =="Cc"||inp[i]+inp[i+1] =="CC"){
//         result1 += 1;
//     }
// }
// alert(result+"\n"+result1);

// 1418 : t를 찾아라
// 입력 : test
// 출력 : 1  4

// let inp = prompt().split("");
// let result = "";
// for(let i=0;i<inp.length;i++){
//     if(inp[i]== "t"){
//         result += (i+1)+" ";
//     }
// }alert(result);

// 1419 : love 2
// 입력 : love lovely
// 출력 : 소문자 love가 몇 번 나오는지 출력한다.

// let inp = prompt().split("");
// let result = 0;
// for(let i=0;i<(inp.length)-3;i++){
//     if(inp[i]+inp[i+1]+inp[i+2]+inp[i+3] == "love"){
//         result++ ;
//     }
// }alert(result);

// 1733 : I.O.I
// 입력 : IOI
// 출력 : 대문자 IOI가 입력되면, IOI is the International Olympiad in Informatics.를 출력하고, 그 외에는 I don't care.를 출력하시오.


// let inp = prompt().split("");
// let result = 0;
// for(let i=0;i<(inp.length)-2;i++){
//     if(inp[i]+inp[i+1]+inp[i+2] == "IOI"){
//         alert("IOI is the International Olympiad in Informatics");
//     }else{
//         alert("I don't care.")
//     }
// }


// 1734 : welcome!
// 입력 : anaki
// 출력 : 예를 들어 ID가 anaki 인 경우, welcome! anaki를 출력한다.

// let inp = prompt();
// let result = "";
// if(inp=="anaki"){
//     alert("welcome! "+inp);
// }


// 1754 : 큰 수 비교
// 입력 : 9999999999999999999999999 9999999999999999999999998
// 출력 : 9999999999999999999999998 9999999999999999999999999

// let inp = prompt().split(" ");
// if(inp[0]>inp[1]){
//     alert(inp[1]+" "+inp[0]);
// }else{
//     alert(inp[0]+" "+inp[1]);
// }

// 1990 : 3의 배수 판별하기
// 입력 : 3321
// 출력 : 3의 배수이면 1을 출력하고, 아니면 0을 출력한다.

// let inp = prompt();
// if(inp%3==0){
//     alert(1);
// }else{
//     alert(0);
// }

// 2721 : 순환 문자열
// 입력 : turtle error robot
// 출력 : 순환 문자열이면 good을 출력, 아니면 bad를 출력하시오.

// 이건 3개의 단어 한정해서 쓰는 로직?임

// let inp = prompt().split(" ");
// let inp1 = inp[0].split("");
// let inp2 = inp[1].split("");
// let inp3 = inp[2].split("");

// if(inp1[inp1.length-1] == inp2[0] && inp2[inp2.length-1] == inp3[0] &&inp3[inp3.length-1] == inp1[0] ){
//     alert("good");
// }else{
//     alert("bad");
// }


// 문자열 끝  


