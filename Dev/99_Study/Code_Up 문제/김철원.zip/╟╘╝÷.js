// 1526 : [기초-함수작성] 함수로 hello 문자열 출력하기

// function inp(){
//     console.log("hello");
// }
// inp()

// 1527 : [기초-함수작성] 함수로 123 값 출력하기
// 입력 : 입력은 없음
// 출력 : 123을 출력한다.

// function inp(){
//     console.log(123);
// }
// inp();

// 1528 : [기초-함수작성] 함수로 *문자 출력하기
// 입력 : 입력은 없음
// 출력 : *을 출력한다.

// function inp(){
//     console.log("*");
// }
// inp();

// 1529 : [기초-함수작성] 함수로 **문자 출력하기
// 입력 : 입력은 없음
// 출력 : **을 출력한다.

// function inp(){
//     console.log("**")
// }inp();

// 1530 : [기초-함수작성] 함수로 문자 A 리턴하기
// 입력 :없음
// 출력 : A를 출력한다.

// function inp(){
//     return "A";
// }
// console.log(inp())


// 1531 : [기초-함수작성] 함수로 정수(int) 1 리턴하기
// 입력 : 입력은 없음
// 출력 : 1을 리턴한다.

// function inp(){
//     return 1;
// }
// console.log(inp());


// 1532 : [기초-함수작성] 함수로 정수(long long int) -2147483649 리턴하기
// 입력 : 입력은 없음
// 출력 : -2147483649을 리턴한다.

// function inp(){
//     return -2147483649;
// }
// console.log(inp());

// 1533 : [기초-함수작성] 함수로 실수(float) 3.14 리턴하기
// 입력 : 입력은 없음
// 출력 : 3.14를 리턴한다.

// function inp(){
//     return 3.14;
// }
// console.log(inp());

// 1534 : [기초-함수작성] 함수로 실수(double) 3.1415926535897 리턴하기
// 입력 : 입력은 없음
// 출력 : 3.1415926535897를 리턴한다.

// function inp(){
//     return 3.1415926535897;
// }
// console.log(inp());

// 1535 : [기초-함수작성] 함수로 가장 큰 값 위치 리턴하기
// 입력 : 첫 줄에 데이터의 개수 n이 입력된다. 두 번째 줄에 n개의 데이터가 공백을 두고 입력된다.
// 출력 : 가장 큰 값이 처음 나타나는 위치를 출력한다.
// 입력 예시 :  5 
//            1 3 2 1 3 
// 출력 예시 : 2

// let inp = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = 0;
// function inp7(){
//     for(let i =0;i<inp-1;i++){
//         if(inp2[i]>inp2[i+1]){
//             result = (i+1);
//             return result;
//         }
//     }
// }
// console.log(inp7());

// 1536 : [기초-함수작성] 함수로 가장 작은 값 리턴하기
// 입력 : 첫 줄에 데이터의 개수 n이 입력된다. 두 번째 줄에 n개의 데이터가 공백을 두고 입력된다.
// 출력 : 가장 작은 값을 출력한다.
// 입력 예시 :  5 
//            1 3 2 1 3 
// 출력 예시 : 1

// let inp = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = 0;
// function inp7(){
//     for(let i =0;i<inp-1;i++){
//         if(inp2[i]<inp2[i+1]){
//             result = (i+1);
//             return result;
//         }
//     }
// }
// console.log(inp7());

// 1537 : [기초-함수작성] 함수로 hello 또는 world 출력하기
// 입력 : int 형 정수(n)가 입력된다
// 출력 : 1 이 입력되면 hello, 2 가 입력되면 world 를 출력한다.

// let inp = Number(prompt());
// function inp2(){
//     if(inp == 1){
//         return "hello";
//     }else if(inp == 2){
//         return "world";
//     }
// }
// console.log(inp2());

// 1538 : [기초-함수작성] 함수로 odd 또는 even 출력하기
// 입력 : int 형 정수(n)가 입력된다.
// 출력 : 홀수가 입력되면 odd, 짝수가 입력되면 even을 출력한다.

// let inp = Number(prompt());
// function inp2(){
//     if(inp%2 == 0){
//         return "even";
//     }else{
//         return "odd";
//     }
// }
// console.log(inp2());

// 1539 : [기초-함수작성] 함수로 false 또는 true 출력하기
// 입력 : int 형 정수(n)가 입력된다.
// 출력 : 0 이 입력되면 false, 그 외에는 true를 출력한다.

// let inp = Number(prompt());
// function inp2(){
//     if(inp == 0){
//         return "false";
//     }else{
//         return "true";
//     }
// }
// console.log(inp2());

// 1540 : [기초-함수작성] 함수로 zero 또는 non zero 출력하기
// 입력 : int 형 정수(n)가 입력된다.
// 출력 : 0 이 입력되면 zero, 그 외에는 non zero를 출력한다.

// let inp = Number(prompt());
// function inp2(){
//     if(inp == 0){
//         return "zero";
//     }else{
//         return "non zero";
//     }
// }
// console.log(inp2());

// 1541 : [기초-함수작성] 함수로 negative/zero/positive 출력하기
// 입력 : int 형 정수(n)가 입력된다
// 출력 : 음수(-) 가 입력되면 negative, 0 이 입력되면 zero, 그 외에는 positive 를 출력한다.

// let inp = Number(prompt());
// function inp2(){
//     if(inp == 0){
//         return "zero";
//     }else if(inp < 0 ){
//         return "negative";
//     }else{
//         return "positive";
//     }
// }
// console.log(inp2());

// 1542 : [기초-함수작성] 함수로 prime 또는 composite 출력하기
// 입력 : int 형 자연수(n)가 입력된다.
// 출력 : 소수(prime)가 입력되면 prime, 합성수(composite)가 입력되면 composite 를 출력한다.

// let inp = Number(prompt());
// let result = "";
// function inp2(){
//     for(let i =2;i<=inp;i++){
//         if(inp%i == 0){
//             result ++;
//         }
//     }if(result == 1){
//         return "prime";
//     }else{
//         return "composite";
//     }    
// }
// console.log(inp2());

// 1543 : [기초-함수작성] 함수로 love 출력하기
// 입력 : 3
// 출력 : 줄을 바꿔가며 love를 n번 출력한다.

// let inp = Number(prompt());
// let result = "";
// function inp2(){
//     for(let i =0;i<inp;i++){
//         result += "love"+"\n";
//     }
//     return result;
// }
// console.log(inp2());


// 1544 : [기초-함수작성] 함수로 * n개 출력하기
// 입력 : n개의 *을 한 줄로 출력한다.
// 출력 : 5

// let inp = Number(prompt());
// let result = "";
// function inp2(){
//     for(let i =0;i<inp;i++){
//         result += "*";
//     }
//     return result;
// }
// console.log(inp2());


// 1545 : [기초-함수작성] 함수로 true(1) / false(0) 리턴하기
// 입력 : int 형 정수(n)가 입력된다.
// 출력 : 0 이 입력되면 zero, 그 외에는 non zero 를 출력한다.

// let inp = Number(prompt());
// function inp2(){
//     if(inp == 0){
//         return "zero";
//     }else{
//         return "non zero";
//     }
// }
// console.log(inp2());

// 1546 : [기초-함수작성] 함수로 plus/minus/0 판별하기
// 입력 : int 형 정수(n)가 입력된다.
// 출력 : 양수인 경우 plus, 음수인 경우 minus, 0 인 경우 zero를 판별하여 출력하시오.

// let inp = Number(prompt());
// function inp2(){
//     if(inp == 0){
//         return "zero";
//     }else if(inp>0){
//         return "plus";
//     }else{
//         return "minus";
//     }
// }
// console.log(inp2());

// 1547 : [기초-함수작성] 함수로 prime/composite 판별하기
// 입력 : int 형 정수(n)가 입력된다.
// 출력 : 소수인 경우 prime, 합성수인 경우 composite 를 출력한다.

// let inp = Number(prompt());
// let result = "";
// function inp2(){
//     for(let i =2;i<=inp;i++){
//         if(inp%i == 0){
//             result ++;
//         }
//     }if(result == 1){
//         return "prime";
//     }else{
//         return "composite";
//     }    
// }
// console.log(inp2());

// 1548 : [기초-함수작성] 함수로 학점 리턴하기
// 입력 : int 형 정수(n)가 입력된다.
// 출력 : 입력한 점수에 따른 학점(A/B/C/D/F)를 출력한다.

// let inp = prompt();
// function inp2(){
//     if(inp>=90 && inp<=100){
//         return "A";
//     }else if(inp>=80 && inp<90){
//         return "B";
//     }else if(inp>=70 && inp<80){
//         return "C";
//     }else if(inp>=60 && inp<70){
//         return "D";
//     }else{
//         return "F";
//     }
// }
// console.log(inp2());

// 1549 : [기초-함수작성] 함수로 절댓값 리턴하기
// 입력 : -2147484648{
// 출력 : 2147484648


// let inp = Number(prompt());
// function inp2() {
//     if(inp > 0){
//         return inp;
//     }else{
//         return -inp;
//     }
// }
// console.log(inp2());

// 1550 : [기초-함수작성] 함수의 양의 제곱근의 정수 부분만 리턴하기
// 입력 : 16
// 출력 : 입력된 정수의 양의 제곱근의 정수부분만 출력한다


// let inp = Number(prompt());
// function inp2() {
//    return Math.sqrt(inp);
// }
// console.log(inp2());

// 1551 : [기초-함수작성] 함수로 원하는 값의 위치 리턴하기 1
// 입력 : 5
//       5 2 3 2 4
//          2
// 출력 : 2

// let inp = prompt(); 
// let inp2 = prompt().split(" ");
// let inp3 = prompt();
// let result = "";

// function inp4 (){
//     for(let i = 0; i<inp;i++){
//         if(inp2[i] == inp3){
//            result = i+1;
//            break
//         }else{
//             result = -1;
//         }   
//     }return result;
// }
// console.log(inp4());

// 1552 : [기초-함수작성] 함수로 소수 부분만 리턴하기
// 입력 : 3.14159265358979
// 출력 : 0.14159265358979    소수 부분만 출력한다.

// let inp = prompt().split(".");

// function inp2 (){
//     return "0."+inp[1];
// }
// console.log(inp2());    

// 1553 : [기초-함수작성] 함수로 정수 올림 한 값 리턴하기
// 입력 : -1.1
// 출력 : -1

// let inp = Number(prompt());
// function inp2 (){
//     return (inp).toFixed(0);
// }
// console.log(inp2());


// 1554 : [기초-함수작성] 함수로 정수 내림 한 값 리턴하기
// 입력 : -1.1
// 출력 : -2

// let inp = Number(prompt());
// function inp2 (){
//     return Math.floor(inp);
// }
// console.log(inp2());

// 1555 : [기초-함수작성] 함수로 n까지의 합 리턴하기
// 입력 : 9999999
// 출력 : 49999995000000
    
// let inp = prompt();
// let result = 0;
// function inp2 () {
//     for(let i = 1; i<=inp;i++){
//         result += i;
//     }
//     return result;
// }
// console.log(inp2());

// 1556 : [기초-함수작성] 함수로 n! 리턴하기
// 입력 : 5
// 출력 : 120

// let inp = prompt();
// let result = 1;
// function inp2 () {
//     for(let i =1;i<=inp;i++){
//         result = result*i;
//     }
//     return result;
// }
// console.log(inp2());

// 1557 : [기초-함수작성] 함수로 n의 약수의 개수 리턴하기
// 입력 : 8
// 출력 : 4

// let inp = Number(prompt());
// let result = 0;
// function inp2 (){
//     for(let i =1;i<=inp;i++){
//         if(inp % i == 0){
//             result += 1;
//         }
//     }
//     return result;
// }
// console.log(inp2());

// 1558 : [기초-함수작성] 함수로 정수 뒤집어 리턴하기
// 입력 : 12305
// 출력 : n의 수를 거꾸로 뒤집은 수를 출력한다.

// let inp = prompt().split("");
// let result = "";
// function inp2 (){
//     for(let i = inp.length-1;i>=0;i--){
//         result += inp[i];
//     }
//     return Number(result);
// }
// console.log(inp2());

// 1559 : [기초-함수작성] 함수로 두 정수의 합 리턴하기
// 입력 : 2147483647 2147483647
// 출력 : 4294967294

// let inp = prompt().split(" ").map(Number);
// let result = 0;
// function inp2 (){
//     return inp[0]+inp[1];
// }
// console.log(inp2());

// 1560 : [기초-함수작성] 함수로 두 정수의 차이 값 리턴하기
// 입력 : 1 2147483648
// 출력 : 2147483647

// let inp = prompt().split(" ").map(Number);
// let result = 0;
// function inp2(){
//     if(inp[0] > inp[1]){
//         return inp[0]-inp[1];
//     }else{
//         return inp[1]-inp[0];
//     }
// }
// console.log(inp2())

// 1561 : [기초-함수작성] 함수로 두 정수의 큰 값 리턴하기
// 입력 : 123 456
// 출력 : 두 수 중 큰 값을 출력한다.

// let inp = prompt().split(" ");
// function inp2 () {
//     if(inp[0] > inp[1]){
//         return inp[0];
//     }else{
//         return inp[1];
//     }
// }
// console.log(inp2());

// 1562 : [기초-함수작성] 함수로 두 정수의 작은 값 리턴하기
// 입력 : 123 456
// 출력 : 두 수 중 작은 값을 출력한다.

// let inp = prompt().split(" ");
// function inp2 () {
//     if(inp[0] > inp[1]){
//         return inp[1];
//     }else{
//         return inp[0];
//     }
// }
// console.log(inp2());

// 1563 : [기초-함수작성] 함수로 세 정수 중 중간 값 리턴하기
// 입력 : 2147483646 2147483647 2147483647
// 출력 : 세 수 중 중간 값을 출력한다.

// let inp = prompt().split(" ").map(Number);
// function inp2() {
//     if(inp[0] > inp [1] && inp[1]> inp[2]){
//         return inp[1];
//     }
//     else if(inp[0] > inp[2] && inp[2] > inp[1]){
//         return inp[2];
//     }
//     else if(inp[1] > inp[0] && inp[0] > inp[2]){
//         return inp[0];
//     }
//     else if(inp[1] > inp[2] && inp[2] > inp[0]){
//         return inp[2];
//     }
//     else if(inp[2] > inp[0] && inp[0] > inp[1]){
//         return inp[0];
//     }
//     else if(inp[2] > inp[1] && inp[1] > inp[0]){
//         return inp[1];
//     }
// }
// console.log(inp2());

// 1564 : [기초-함수작성] 함수로 최대공약수 리턴하기
// 입력 : 160 96
// 출력 : 두 수의 최대공약수를 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = 0;
// function inp2 () {
//     for(let i = 2; i<Math.min(inp[0], inp[1]);i++){
//         if(inp[0] % i == 0 && inp[1] % i == 0){
//             result = i;
//         }
//     }return result;
// }
// console.log(inp2());

// 1565 : [기초-함수작성] 함수로 최소공배수 리턴하기
// 입력 : 192 72
// 출력 : 두 수의 최소공배수를 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = 1;
// function inp2 () {
//     while(true){
//         if((result % inp[0] == 0) && (result % inp[1] == 0)){
//           break;
//         }
//         result++;
//     }
//     return result;
// }
// console.log(inp2());

// 1566 : [기초-함수작성] 함수로 거듭제곱 리턴하기
// 입력 : 2 61  2305843009213694000  2305843009213693952 ??? 48은 왜 더해진거지
// 출력 : a 를 n 번 거듭제곱한 결과를 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = 1;
// function inp2() {
//     return Math.pow(inp[0],inp[1])
// }
// console.log(inp2());

// 1567 : [기초-함수작성] 함수로 배열의 부분합 리턴하기
// 입력 : 5
//       1 5 4 3 2
//       2 4
// 출력 : 12

// let inp = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let inp3 = prompt().split(" ").map(Number);
// let result = 0;
// function inp4 () {
//     for(let i = 0; i<=inp3[1]-inp3[0];i++){
//         result  += inp2[inp3[0]-1+i]
//     }
//     return result;
// }
// console.log(inp4());


// 1568 : [기초-함수작성] 함수로 배열의 최대값 위치 리턴하기
// 입력 : 5
//      1 5 4 3 2
//      3  5
// 출력 : 3

// let inp = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let inp3 = prompt().split(" ").map(Number);
// let result = 0;
// let result2 = 0;
// function inp0() {
//     for(let i = 0; i<=inp3[1]-inp3[0];i++){
//         if(result <inp2[inp3[0]-1+i]){
//             result = inp2[inp3[0]-1+i];
//         }else{
//             result = result;
//         }
//     }
//     for(let j = 0;j<inp;j++){
//         if(result == inp2[j]){
//             result2 = j+1;
//         }
//     }
//     return result2;
// }
// console.log(inp0());

// 1569 : [기초-함수작성] 함수로 배열의 최대값 위치 리턴하기 2
// 입력 : 5
//      1 3 5 7 9
//       3
// 출력 : 2 

// let inp = Number(prompt());
// let inp2 = prompt().split(" ").map(Number);
// let inp3 = prompt().split(" ").map(Number);
// let result = 0;
// function inp0() {
//     for(let i =0;i<inp;i++){
//         if(inp3 == inp2[i]){
//             result = i+1;
//             break;
//         }else if(i == inp-1){
//             result = -1;
//         }
//     }return result;
// }
// console.log(inp0());


// 1570 : [기초-함수작성] 함수로 Lower Bound 위치 리턴하기
// 입력 : 5
//      1 3 5 7 9
//      4    
// 출력 : 3 , 입력된 값보다 크거나 같은 값이 저장되어있는 처음 위치를 출력한다.

// let inp = Number(prompt());
// let inp2 = prompt().split(" ").map(Number);
// let inp3 = prompt().split(" ").map(Number);
// let result = 0;
// function inp0() {
//     for(let i =0;i<inp;i++){
//         if(inp3 <= inp2[i]){
//             result = i+1;
//             break;
//         }else if(i == inp-1){
//             result = inp+1;
//         }
//     }return result;
// }
// console.log(inp0());

// 1571 : [기초-함수작성] 함수로 Upper  Bound 위치 리턴하기
// 입력 : 5
//      1 3 5 7 9
//      4    
// 출력 : 3 , 입력된 값보다 크거나 같은 값이 저장되어있는 처음 위치를 출력한다.

// let inp = Number(prompt());
// let inp2 = prompt().split(" ").map(Number);
// let inp3 = prompt().split(" ").map(Number);
// let result = 0;
// function inp0() {
//     for(let i =0;i<inp;i++){
//         if(inp3 < inp2[i]){
//             result = i+1;
//             break;
//         }else if(i == inp-1){
//             result = inp+1;
//         }
//     }return result;
// }
// console.log(inp0());


// 모르는것 1차원배열 1문제 문자열 1문제