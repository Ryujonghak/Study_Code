// 1차원 배열 시작

// 1402 : 거꾸로 출력하기 3
// 입력 : 5
//     1 3 5 6 8
// 출력 : n개의 데이터를 입력의 역순으로 출력한다.

// let inp1 = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = "";
// for(let i=inp1;i>0;i--){
//     result = result+" "+inp2[(i)-1]; 
// }alert(result);


// 1403 : 배열 두번 출력하기
// 입력 : 3
//       1 2 3
// 출력 : k개의 숫자를 입력받은 순서대로 한 줄에 하나씩 출력한다. 
//        그리고 한번 출력이 다 되면 다시 한번더 출력한다.(총 2번)

// let inp1 = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = "";
// for(let i=1;i<inp1;i++){
//     for(let j=0;j<inp1;j++){
//         result += inp2[j]+"\n";
//     }
// }alert(result);

// 1405 : 숫자 로테이션
// 입력 :   5 
//       1 2 3 4 5 
// 출력 : 숫자를 로테이션한 결과를 출력한다.(단, 왼쪽으로만 돌린다.)

// let inp = prompt()
// let inp2 = prompt().split(" ").map(Number);
// let result = "";
// for(let h =0;h<inp;h++){
//     result += " "+inp2[h];
//     if(h==(inp-1)){
//         result += " \n"
//     }
// }
// for(let i= 1;i<inp;i++){
//     for(let j=i;j<inp;j++){
//         result += " "+inp2[j];         // 2345    345        45    5
        
//     }
//     for(let k=0;k<i;k++){
//         result += " "+inp2[k];        //  1       12         123    1234
        
//     }
//     result += " \n";
// }alert(result);

// 1407 : 문자열 출력하기 1
// 입력 : 문자열이 입력된다.(글자 수는 100글자 이하이고, 알파벳 대소문자와 공백 문자만 입력된다.)
// 출력 : 공백을 제거한 후 출력한다.

// let inp2 = prompt().split(" ");
// let result = "";
// for(let i =0; i<inp2.length;i++){
//     result += inp2[i];
// }alert(result);

// 1409 : 기억력 테스트 1
// 입력 : 10 9 8 7 6 5 4 3 2 1  
//        3  k번째 숫자
// 출력 : k번째 숫자가 무엇이었는지 출력한다.

// let inp = prompt().split(" ").map(Number);
// let inp2 = prompt()
// let result = "";
// result = inp[inp2-1];
// alert(result);


// 1410 : 올바른 괄호 1 (괄호 개수 세기)
// 입력 : 괄호로 이루어진 문자열이 입력된다. (길이 100,000 이하)
// 출력 : 여는 괄호의 개수와 닫힌 괄호의 개수를 출력한다.

// let inp = prompt().split("");
// let result1 = 0;
// let result2 = 0;
// for(let i=0; i<inp.length;i++){
//     if(inp[i]== "(" ){
//         result1 += 1;
//     }
//     if(inp[i]== ")" ){
//         result2 += 1;
//     }
// }alert(result1 +" "+ result2);

// 1411 : 빠진 카드
// 입력 : 10
//        3 4 1 10 2 6 7 5 9 (세로로 되어 있는것을 가로로 변경해서 했습니다).
// 출력 : 여러분은 주 어진 카드 묶음에서 빠진 하나의 카드를 찾아서 그 번호를 출력해야 한다.

// let inp2 = prompt()
// let inp = prompt().split(" ").map(Number);
// let result = 0;
// let result2 = 0;
// for(let i= 1;i<=inp2;i++){
//     result += i;  
// }
// for(let j= 0;j<inp.length;j++){
//     result2 += inp[j];
// }
// alert(result-result2);

// 1412 : 알파벳 개수 출력하기
// 입력 : oh! my god!
// 출력 : a부터 z까지 사용된 알파벳 개수를 [입출력 예시]를 참고하여 출력한다. 특수문자와 공백의 개수는 출력하지 않는다.


let inp = prompt();
let result = 0;
let result2 = new Array(26)
let result3 = "";


for(let i=0;i<result.length; i++){
    result2[i] = 0;
}
// 이렇게 하면 result2에 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 이렇게 담김

for(let i = 0;i<inp.length;i++){
    result += " "+inp[i].charCodeAt(0);   // 문자의 개수 만큼 결과값에 아스키 코드로 담는다. // 0 111 104 33 32 109 121 32 103 111 100 33
}

let inp2 = result.split(" "); // 0,111,104,33,32,109,121,32,103,111,100,33

for(let i = 1 ; i < inp.length;i++){
    // 여기에 아스키 코드 -97하면 해당 아스키코드 알파벳 위치에 카운팅을 한다리
    if(inp2[i]== 32 || inp2[i]== 33){ 
        continue;                                //  공백,!랑 무시
    }
    result2[inp2[i]-97]++;
}

for(let i = 0;i<26;i++){
    result3 += String.fromCharCode(i+97)+":"+result2[i]+"\n"; 
}
console.log(result3);


// 1416 : 2진수 변환
// 입력 : 7
// 출력 : 2진수로 변환해서 출력한다

// let inp = Number(prompt());
// let inp2 = inp.toString(2);
// alert(inp2);

// 1420 : 3등 찾기 
// 입력 : minsu 78
//       gunho 64
//      sumin 84
//      jiwon 96
//      woosung 55
// 출력 : minsu

// let inp1 = prompt().split(" ");
// let inp2 = prompt().split(" ");
// let inp3 = prompt().split(" ");
// let inp4 = prompt().split(" ");
// let inp5 = prompt().split(" ");

// let inp6 = inp1.concat(inp2,inp3,inp4,inp5,);
// let result = "";
// let result2 = "";
// for(let i =1; i<inp6.length;i++){
//     if(i % 2 != 0){
//         result += " "+inp6[i];
//     }
// }
// let inp7 = result.split(" ");

// inp7.sort(function(a,b){
//     return a - b;
// }); // 맨앞에 빈 공간이 있기때문에

// for(let i = 1; i<inp7.length;i++){
//     if(inp7[3] == inp6[i]){
//         result2 = inp6[i-1];
//     }
// }
// alert(result2);





// 1425 : 자리 배치
// 입력 : 9 6
//        160 165 164 165 150 165 168 145 170 
// 출력 : 145 150 160 164 165 165 
//        165 168 170 

// let inp1 = prompt().split(" ");
// let inp = prompt().split(" ").map(Number);
// let result = "";
// inp.sort((a, b) => a - b);
// for(let i = 0; i<inp1[0];i++){
//     result += " "+inp[i];
//     if((inp1[1]-1)==i){
//         result += "\n";
//     }
// }alert(result);

// 1430 : 기억력 테스트 2
// 입력 : 5
//       2 52 23 55 100
//       4
//       5 2 55 99
// 출력 : 0 1 1 0 

// let inp5 = prompt();
// let inp1 = prompt().split(" ").map(Number);
// let inp4 = prompt();
// let inp2 = prompt().split(" ").map(Number);
// let result = "";
// for(let i=0; i<inp4;i++){
//     for(let j =0; j<inp5;j++){
//         if(inp2[i]==inp1[j]){
//             result += 1+" ";
//             break;
//         }else if(j == (inp4-1)){
//             result += 0+" ";
//             break;
//         }
//     }
// }alert(result);

// 1440 : 비교
// 입력 : 5
//        1 2 3 2 1 
// 출력 :1: < < < = 
//      2: > < = > 
//      3: > > > > 
//      4: > = < > 
//      5: = < < < 



// let inp = prompt();
// let inp1 = prompt().split(" ");
// let result = "";

// for(let i=0;i<inp;i++){
//     for(let j=0;j<inp;j++){
//         if(i == j){
//             continue;
//         }
//         else if(inp1[i]>inp1[j]){
//             result += ">"+" ";
//         }
//         else if(inp1[i]==inp1[j]){
//             result += "="+" ";
//         }
//         else if(inp1[i]<inp1[j]){
//             result += "<"+" ";
//         }
//         if(j==(inp-1)){
//             result += "\n"
//         }
//     }
// }alert(result);

// 1차원 배열 끝
