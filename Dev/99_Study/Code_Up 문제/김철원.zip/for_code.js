// 1284 : 암호 해독
// 입력 : 어떤 수 n이 입력된다.(단, 1<=n<=10,000,000)
// 출력 : n을 두 소수의 곱으로 나타낼 수 있으면 두 수를 오름차순으로 출력한다. (단, 가능한 소수 중 가장 작은 소수와의 곱으로 나타낸다.) 하고, 그렇지 않으면 "wrong number"를 출력한다.
// 입력예시 : 21
// 출력예시 : 3 7

let inp = Number(prompt());
let result = "";
let result2 = "";
let result3 = "";
for(let i = 2;i<inp;i++){
	if(inp%i == 0){
        result += " "+i;
    }
}
let inp2 = result.split(" ");
// ,2,11               inp2.length = 3
for(let i = 1 ;i<inp2.length;i++){
   for(let j = 2;j<=inp/2;j++){
        if(inp2[i] == j){
            result2 += " "+inp2[i];
            continue;
        }
        else if(inp2[i]%j ==0){
            break;
        }
    }
}
// 공백,2,11               inp3.length = 3        // 소수인것만 넣고 합성수,소수가 아닌것들을 걸러냄,  입력값이랑 
let inp3 = result2.split(" ");
if(inp3[1]*inp3[2] == inp){
    alert(inp3[1]+ " " +inp3[2]);  
}else{
    alert("wrong number");
}



// 1287 : 구구단을 *로 출력하기
// 입력 : 2
// 출력 : **
//       ****
//       ******
//       ********
//       **********
//       ************
//       **************
//       ****************
//       ******************

// let inp = Number(prompt());
// let result ="";
// for(let i = 1;i<=9;i++){
//     for(let j = 1; j<=(inp*i);j++){
//         result += "*";
//     }
//     result += "\n";
// }alert(result);