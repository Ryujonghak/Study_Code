// 1151 : 10보다 작은 수
// 입력 : 5
// 출력 : 10미만이면 small을 출력한다.

// let inp = prompt();
// if(inp<10){
//     alert("small");
// }

// 1152 : 10보다 작은 수 (else 버전)
// 입력 : 5
// 출력 : 10미만 : small , 10이상 : big 을 출력한다.

// let inp = prompt();
// if(inp<10){
//     alert("small");
// }else{
//     alert("big")
// }

// 1153 : 두 수의 대소 비교
// 입력 : 2 6
// 출력 : a가 b보다 크면  > 를 출력, b가 a보다 크면  < 를 출력 , a와 b가 같으면  = 를 출력한다.

// let inp = prompt().split(" ").map(Number);
// if(inp[0]>inp[1]){
//     alert(">");
// }else if(inp[0]<inp[1]){
//     alert("<");
// }else{
//     alert("=");
// }

// 1154 : 큰수 - 작은수
// 입력 : 5 7
// 출력 : 큰수 - 작은 수의 값이 출력된다.

// let inp = prompt().split(" ").map(Number);
// if(inp[0]>inp[1]){
//     alert(inp[0]-inp[1]);
// }else if(inp[0]<inp[1]){
//     alert(inp[1]-inp[0]);
// }else{
//     alert(0);
// }

// 1155 : 7의 배수
// 입력 : 9
// 출력 : 7의 배수일 경우 multiple를 출력하고, 7의 배수가 아니면 not multiple을 출력하시오.

// let inp = prompt();
// if(inp%7 == 0){
//     alert("multiple");
// }else{
//     alert("not multiple");
// }

// 1156 : 홀수 짝수 구별
// 입력 : 5
// 출력 : 홀수이면 odd를 출력, 짝수이면 even을 출력하시오.

// let inp = prompt();
// if(inp%2 == 0){
//     alert("even");
// }else{
//     alert("odd");
// }

// 1157 : 특별한 공 던지기 1
// 입력 : 50.213
// 출력 : 50이상 60이하이면 win을 출력, 그 외에는 lose를 출력하시오.

// let inp = prompt();
// if(inp>=50 && inp<=60){
//     alert("win");
// }else{
//     alert("lose");
// }


// 1158 : 특별한 공 던지기 2
// 입력 : 50
// 출력 : 공이 떨어지는 위치 n이 30≤n≤40 이거나 60≤n≤70 이면, win을 출력, 그외에는 lose를 출력한다.

// let inp = prompt();
// if(inp>=30  && inp <=40){
//     alert("win");
// }else if(inp>=60 && inp<=70){
//     alert("win");
// }
// else{
//     alert("lose");
// }

// 1159 : 특별한 공 던지기 3
// 입력 : 30
// 출력 : 1. 공의 위치가 50m~70m이면 슬기가 이김, 2. 공의 위치가 6의 배수이면 슬기가 이김. 승리 조건을 잘 보고 슬기가 이기는 조건이면 win, 그외에는 lose를 출력하시오.

// let inp = prompt();
// if(inp>=50  && inp <=70){
//     alert("win");
// }else if(inp%6==0){
//     alert("win");
// }
// else{
//     alert("lose");
// }

// 1160 : 아르바이트 가는 날
// 입력 : 1
// 출력 : 주원이는 월, 수, 금, 일 아르바이트를 간다, 아르바이트 가는 날이면 "oh my god"를 가는 날이 아니면 "enjoy"를 출력하시오.


// let inp = prompt();
// if(inp == 1 ||inp == 3 ||inp == 5 ){
//     alert('"oh my god"');
// }else{
//     alert('"enjoy"');
// }

// 1161 : 홀수와 짝수 그리고 더하기
// 입력 : 2 3
// 출력 : 만약 첫번째 정수가 홀수이면 "홀수"를 출력하고, 짝수이면 "짝수"를 출력한 후  "+"를 출력한다. 
//       그리고 두번째 정수가 홀수이면 "홀수"를 출력하고, 짝수이면 "짝수"를 출력한 후  "="을 출력하고 결과로 나오는 값이 홀수인지 짝수인지 출력한다.

// let inp = prompt().split(" ").map(Number);
// let result = "";
// if(inp[0]%2 == 0){
//     result += "짝수"+"+";
// }else{
//     result += "홀수"+"+";
// }
// if(inp[1]%2 == 0){
//     result += "짝수"+"=";
// }else{
//     result += "홀수"+"=";
// }if((inp[0]+inp[1])%2 == 0){
//     result += "짝수";
// }else{
//     result += "홀수";
// }
// alert(result);

// 1162 : 당신의 사주를 봐 드립니다 1
// 입력 : 1902 2 10
// 출력 : 년도 - 월 + 일의 마지막 숫자가 0이면 "대박"을 , 그렇지 않으면 "그럭저럭"을 출력하시오.

// let inp = prompt().split(" ").map(Number);
// let inp2 = inp[0]-inp[1]+inp[2]
// if(inp2%10==0){
//     alert("대박");
// }else{
//     alert("그럭저럭");
// }

// 1163 : 당신의 사주를 봐 드립니다 2
// 입력 : 1502 2 10
// 출력 : 년도 + 월 + 일의 100의 자리가 숫자가 짝수이면 "대박"을 , 그렇지 않으면 "그럭저럭"을 출력하시오.

// width = Math.floor((inp2)/100) * 100; 100의자리 이하 버림

// let inp = prompt().split(" ").map(Number);
// let inp2 = inp[0]+inp[1]+inp[2]
// let inp3 = Math.floor((inp2)/100)*100;
// if(inp3%200==0){
//     alert("대박");
// }else{
//     alert("그럭저럭");
// }


// 1164 : 터널 통과하기 1
// 입력 : 170 168 175
// 출력 : 170보다 같거나 작으면 "CRASH"를 출력, 그 보다 크면 "PASS"를 출력하시오.

// let inp = prompt().split(" ").map(Number);
// if(170<=inp[0] && 170<=inp[1] && 170<=inp[2] ){
//     alert("PASS");
// }else{
//     alert("CRASH");
// }

// 1165 : 축구의 신 1
// 입력 : 74 2
// 출력 : 성익이는 5분마다 골을 넣을 수 있는 능력을 가지고 있다. 경기가 끝났을때 우리팀의 득점을 출력한다.

// let inp = prompt().split(" ").map(Number);
// let inp2 = Math.floor((90-inp[0])/5+1);
// if((90-inp[0])%5==0){
//     alert(inp2+1+inp[1]);
// }else{
//     alert(inp2+inp[1]);
// }


// 1166 : 윤년 판별
// 입력 : 
// 출력 : 입력받은 자연수가 윤년이라면 "Leap"를 아니라면 "Normal"을 출력한다.

// let inp = Number(prompt());
// if(inp%400 == 0 ){
//     alert("Leap");
// }else if(inp%4 ==0 && inp%100 != 0){
//     alert("Leap");
// }else{
//     alert("Normal");
// }

// 1167 : 두 번째 수
// 입력 : 201 20 3
// 출력 : 세 개의 정수를 작은 순서로 나열 했을 때, 두번째 수를 출력한다.

// let inp = prompt().split(" ");
// if(inp[0]>inp[1] && inp[1]>inp[2]){
//     alert(inp[1]);
// }else if(inp[0]>inp[2] && inp[2]>inp[1]){
//     alert(inp[2]);
// }else if(inp[1]>inp[0] && inp[0]>inp[2]){
//     alert(inp[0]);
// }else if(inp[1]>inp[2] && inp[2]>inp[0]){
//     alert(inp[2]);
// }else if(inp[2]>inp[0] && inp[0]>inp[1]){
//     alert(inp[0]);
// }else if(inp[2]>inp[1] && inp[1]>inp[0]){
//     alert(inp[1]);
// }


// 1168 : 나이 계산 1
// 입력 : 790101 1
// 출력 : 2012년도에 현재 나이를 출력하시오.

// let inp = prompt().split(" ").map(Number);
// if(inp[1] == 1 || inp[1] == 2){
//     alert(112-Math.floor(inp[0]/10000)+1)
// }else if(inp[1] == 3 || inp[1] == 4){
//     alert(12-Math.floor(inp[0]/10000)+1)
// }


// 1169 : 나이 계산 2 
// 입력 : 18
// 출력 : 출생년도 뒤의 두자리와 연도정보(1이면 1900년대, 3이면 2000년대)를 출력한다.
//        95 1

// let inp = prompt();
// if(inp>13){
//     alert(113-inp +" 1")
// }else{
//     alert(13-inp +" 1")
// }

// 1170 : 당신의 학번은? 1
// 입력 : 3 1 2
// 출력 : 학번을 붙여서 출력한다. 번호가 10번 미만일때는 0을 붙여 출력한다.


// let inp = prompt().split(" ");
// if(inp[2]<10){
//     alert(inp[0]+inp[1]+"0"+inp[2]);
// }else{
//     alert(inp[0]+inp[1]+inp[2]);
// }

// 1171 : 당신의 학번은? 2
// 입력 : 2 7 15
// 출력 : 207015

// let inp = prompt().split(" ");
// if(inp[1]<10){
//     if(inp[2]>=100){
//         alert(inp[0]+"0"+inp[1]+inp[2]);
//     }else if(inp[2]>=10){
//         alert(inp[0]+"0"+inp[1]+"0"+inp[2]);
//     }else{
//         alert(inp[0]+inp[1]+"00"+inp[2]);
//     }
// }else if(inp[2]>=100){
//     alert(inp[0]+inp[1]+inp[2]);
// }else if(inp[2]>=10){
//     alert(inp[0]+inp[1]+"0"+inp[2]);
// }else if(inp[2]<10){
//     alert(inp[0]+inp[1]+"00"+inp[2]);
// }else{
//     alert(inp[0]+inp[1]+inp[2]);
// }


// 1172 : 세 수 정렬하기
// 입력 : 8 7 6
// 출력 : 세 수를 오름차순으로 정렬하려고 한다. (낮은 숫자 -> 높은 숫자)


// let inp = prompt().split(" ");
// if(inp[0]>inp[1] && inp[1]>inp[2]){
//     alert(inp[2]+" "+inp[1]+" "+inp[0]);    
// }
// else if(inp[0]>inp[2] && inp[2]>inp[1]){
//     alert(inp[1]+" "+inp[2]+" "+inp[0]);
// }
// else if(inp[1]>inp[0] && inp[0]>inp[2]){
//     alert(inp[2]+" "+inp[0]+" "+inp[1]);
// }
// else if(inp[1]>inp[2] && inp[2]>inp[0]){
//     alert(inp[0]+" "+inp[2]+" "+inp[1]);
// }
// else if(inp[2]>inp[0] && inp[0]>inp[1]){
//     alert(inp[1]+" "+inp[0]+" "+inp[2]);
// }
// else if(inp[2]>inp[1] && inp[1]>inp[0]){
//     alert(inp[0]+" "+inp[1]+" "+inp[2]);
// }


// 1173 : 30분전
// 입력 : 12 35
// 출력 : 12 05
// let inp = prompt().split(" ").map(Number);
// if(inp[1]>=30){
//     alert(inp[0]+ " " +(inp[1]-30));
// }else if(inp[1]<30){
//     alert(inp[0]-1 + " "+(inp[1]+30))
// }