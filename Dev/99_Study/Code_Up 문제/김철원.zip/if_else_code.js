// 기초3.if~else
// 되도록이면 if / else를 주로 사용해서 풀겠습니다.

// 1202 : 등급 판정
// 입력 : 점수가 정수로 입력된다. (입력되는 정수는 0~100이다)
// 출력 : 점수에 따라 등급을 출력한다.
// 입력예시 : 80
// 출력예시 : B

// let score = prompt("점수를 입력해주세요")
// if(score>= 90 && score<=100){
//     alert("A");
// }else if(score>= 80 && score<90){
//     alert("B");
// }else if(score>= 70 && score<80){
//     alert("C");
// }else if(score>= 60 && score<70){
//     alert("D");
// }else{
//     alert("F");
// }


// 1210 : 칼로리 계산하기
// 입력 : 메뉴의 번호가 차례대로 두개 주어진다. (정수)
// 출력 : 그 번호의 메뉴 칼로리를 계산하여 500보다 크면 "angry", 500이하면 "no angry"를 출력하시오.
// 입력예시 : 1 2
// 출력예시 : angry

// let number = prompt("주문할 메뉴번호를 공백을 두고 입력해주세요").split(" ");
// let calorie = 0;

// if(number[0] == 1){
//     calorie += 400;
// }else if(number[0] == 2){
//     calorie += 340;
// }else if(number[0] == 3){
//     calorie += 170;
// }else if(number[0] == 4){
//     calorie += 100;
// }else if(number[0] == 5){
//     calorie += 70;
// }

// if(number[1] == 1){
//     calorie += 400;
// }else if(number[1] == 2){
//     calorie += 340;
// }else if(number[1] == 3){
//     calorie += 170;
// }else if(number[1] == 4){
//     calorie += 100;
// }else if(number[1] == 5){
//     calorie += 70;
// }

// if(calorie > 500){
//     alert("angry")
// }else{
//     alert("no angry")
// }

// 1218 : 삼각형 판단하기
// 입력 : 변의 길이 a, b, c가 입력된다. ( 정수)
// 출력 : 조건에 따라 삼각형을 출력한다.
//       조건)
//       세 변의 길이가 같은 경우 : 정삼각형
//       두 변의 길이가 같은 경우 : 이등변삼각형
//       a2 + b2 = c2일 경우(피타고라스 정리) : 직각삼각형
//       위의 조건에 맞지 않는 일반 삼각형일 경우 : 삼각형
//       삼각형이 아닐 경우 : 삼각형아님을 출력한다
// 입력예시 : 3 3 3
// 출력예시 : 정삼각형

// let inp = prompt().split(" ").map(Number);
// if(inp[0] == inp[1]  && inp[1] == inp[2]){
//     alert("정삼각형")
// }
// else if(inp[0] == inp[1]  && inp[1] < inp[2]){
//     alert("이등변삼각형")
// }
// else if((( inp[0] * inp[0] ) + ( inp[1] * inp[1] ))    == (inp[2]*inp[2])){
//     alert("직각삼각형")
// }
// else if(inp[0] <= inp[1] && inp[1] <= inp[2]){
//     alert("삼각형")
// }else{
//     alert("삼각형아님")
// }


// 1228 : 비만도 측정 1
// 입력 : 희윤이의 키와 몸무게가 공백을 기준으로 입력된다.(실수)
// 출력 : 희윤이의 비만도에 따른 등급을 출력한다.(설명 참조)
// 입력예시 : 170.0 80.0
// 출력예시 : 비만

// let inp = prompt("키와 몸무게를 입력해주세요").split(" ");
// let 표준몸무게 = (inp[0] - 100) * 0.9;
// let 비만도 = (inp[1]- 표준몸무게)*100/표준몸무게;

// if(비만도 >20){
//     alert("비만");
// }else if(비만도>10 && 비만도<=20){
//     alert("과체중");
// }else if(비만도<=10){
//     alert("정상");
// }
